import { useEffect, useState } from 'react';
import { auth, db } from '../firebase';
import { doc, getDoc, setDoc, onSnapshot } from 'firebase/firestore';
import { useAuthState } from 'react-firebase-hooks/auth';
import { UserProfile } from '../types';

export function useUser() {
  const [authUser, loadingAuth] = useAuthState(auth);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loadingProfile, setLoadingProfile] = useState(true);

  useEffect(() => {
    if (loadingAuth) return;

    if (!authUser) {
      setProfile(null);
      setLoadingProfile(false);
      return;
    }

    const userRef = doc(db, 'users', authUser.uid);

    const unsubscribe = onSnapshot(userRef, async (snapshot) => {
      if (snapshot.exists()) {
        setProfile(snapshot.data() as UserProfile);
        setLoadingProfile(false);
      } else {
        // Create profile if it doesn't exist
        const newProfile: UserProfile = {
          uid: authUser.uid,
          email: authUser.email || '',
          displayName: authUser.displayName || 'Agent',
          photoURL: authUser.photoURL || '',
          role: 'user',
          createdAt: new Date().toISOString(),
          lastLogin: new Date().toISOString(),
          securityStatus: 'secure'
        };
        await setDoc(userRef, newProfile);
        setProfile(newProfile);
        setLoadingProfile(false);
      }
    });

    return () => unsubscribe();
  }, [authUser, loadingAuth]);

  return { user: authUser, profile, loading: loadingAuth || loadingProfile };
}
