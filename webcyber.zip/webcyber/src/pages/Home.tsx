import React from 'react';
import { motion } from 'framer-motion';
import { Shield, Lock, Zap, Globe, ArrowRight, Terminal } from 'lucide-react';
import { Link } from 'react-router-dom';

const Home: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      {/* Hero Section */}
      <section className="min-h-[80vh] flex flex-col items-center justify-center text-center space-y-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="space-y-4"
        >
          <div className="inline-flex items-center space-x-2 px-3 py-1 border border-cyber-green/30 bg-cyber-green/5 rounded-full mb-4">
            <Terminal className="w-4 h-4 text-cyber-green" />
            <span className="text-[10px] text-cyber-green tracking-[0.2em] uppercase">System Status: Operational</span>
          </div>
          <h1 className="text-5xl md:text-7xl font-black tracking-tighter leading-none">
            CYBER SECURITY<br />
            <span className="text-cyber-blue">PROTECTION SYSTEM</span>
          </h1>
          <p className="max-w-2xl mx-auto text-gray-400 text-sm md:text-base font-light tracking-wide">
            Advanced digital defense for the modern era. Secure your assets with our state-of-the-art 
            vulnerability scanning and AI-driven threat intelligence.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="flex flex-col sm:flex-row items-center gap-4"
        >
          <Link to="/dashboard" className="cyber-button flex items-center space-x-2">
            <span>SCAN SECURITY</span>
            <Shield className="w-4 h-4" />
          </Link>
          <button className="px-8 py-2 text-sm border border-white/10 hover:bg-white/5 transition-colors uppercase tracking-widest">
            CONTACT BOT
          </button>
        </motion.div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 pt-12 w-full max-w-4xl">
          {[
            { label: 'Threats Blocked', value: '2.4M+' },
            { label: 'Active Nodes', value: '15.8K' },
            { label: 'Response Time', value: '0.4ms' },
            { label: 'Security Score', value: '99.9%' },
          ].map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.8 + i * 0.1 }}
              className="text-center"
            >
              <div className="text-2xl font-bold text-cyber-blue">{stat.value}</div>
              <div className="text-[10px] text-gray-500 uppercase tracking-widest mt-1">{stat.label}</div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-24 grid grid-cols-1 md:grid-cols-3 gap-8">
        <FeatureCard 
          icon={<Lock className="w-8 h-8 text-cyber-blue" />}
          title="Encrypted Data"
          description="End-to-end encryption for all your sensitive information using military-grade protocols."
        />
        <FeatureCard 
          icon={<Zap className="w-8 h-8 text-cyber-green" />}
          title="Real-time Analysis"
          description="Instant threat detection and response powered by our distributed neural network."
        />
        <FeatureCard 
          icon={<Globe className="w-8 h-8 text-cyber-red" />}
          title="Global Network"
          description="Protection that scales with your business, covering nodes across 120+ countries."
        />
      </section>

      {/* Security Knowledge Section */}
      <section className="py-12 border-t border-cyber-blue/10">
        <div className="flex flex-col md:flex-row items-center gap-12">
          <div className="flex-1 space-y-6">
            <h2 className="text-3xl font-bold tracking-widest text-cyber-blue uppercase">Pusat Edukasi Keamanan</h2>
            <p className="text-gray-400 text-sm leading-relaxed">
              Pelajari dasar-dasar keamanan siber untuk melindungi diri Anda dan organisasi Anda dari ancaman digital yang terus berkembang. Kami menyediakan materi edukasi tentang phishing, malware, dan praktik terbaik keamanan.
            </p>
            <Link to="/blog" className="cyber-button inline-flex items-center space-x-2">
              <span>BACA MATERI LENGKAP</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
          <div className="flex-1 grid grid-cols-2 gap-4">
            <div className="cyber-card p-4 border-cyber-blue/20 bg-cyber-blue/5 text-center">
              <div className="text-2xl mb-2">🎣</div>
              <div className="text-[10px] font-bold uppercase tracking-widest">Anti-Phishing</div>
            </div>
            <div className="cyber-card p-4 border-cyber-green/20 bg-cyber-green/5 text-center">
              <div className="text-2xl mb-2">🔑</div>
              <div className="text-[10px] font-bold uppercase tracking-widest">Password Safety</div>
            </div>
            <div className="cyber-card p-4 border-cyber-red/20 bg-cyber-red/5 text-center">
              <div className="text-2xl mb-2">🦠</div>
              <div className="text-[10px] font-bold uppercase tracking-widest">Malware Defense</div>
            </div>
            <div className="cyber-card p-4 border-white/10 bg-white/5 text-center">
              <div className="text-2xl mb-2">🛡️</div>
              <div className="text-[10px] font-bold uppercase tracking-widest">Best Practices</div>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-24">
        <div className="cyber-card flex flex-col md:flex-row items-center justify-between gap-8 border-cyber-green/30">
          <div className="space-y-2">
            <h2 className="text-2xl font-bold tracking-tight">READY TO SECURE YOUR DIGITAL FRONTIER?</h2>
            <p className="text-sm text-gray-400">Join 50,000+ companies protected by CyberGuard Pro.</p>
          </div>
          <Link to="/login" className="cyber-button bg-cyber-green/10 border-cyber-green text-cyber-green hover:bg-cyber-green hover:text-black">
            GET STARTED NOW
          </Link>
        </div>
      </section>
    </div>
  );
};

const FeatureCard: React.FC<{ icon: React.ReactNode, title: string, description: string }> = ({ icon, title, description }) => (
  <motion.div 
    whileHover={{ y: -5 }}
    className="cyber-card group"
  >
    <div className="mb-6 group-hover:scale-110 transition-transform">{icon}</div>
    <h3 className="text-lg font-bold mb-2 tracking-widest uppercase">{title}</h3>
    <p className="text-sm text-gray-400 font-light leading-relaxed">{description}</p>
    <div className="mt-6 flex items-center text-[10px] text-cyber-blue tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">
      LEARN MORE <ArrowRight className="w-3 h-3 ml-2" />
    </div>
  </motion.div>
);

export default Home;
