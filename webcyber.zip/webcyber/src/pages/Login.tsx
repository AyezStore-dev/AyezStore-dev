import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Shield, Smartphone, Mail, ArrowRight, Lock } from 'lucide-react';
import { signInWithGoogle } from '../firebase';
import { useNavigate } from 'react-router-dom';

const Login: React.FC = () => {
  const [method, setMethod] = useState<'google' | 'phone'>('google');
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [step, setStep] = useState(1);
  const navigate = useNavigate();

  const handleGoogleLogin = async () => {
    try {
      await signInWithGoogle();
      navigate('/dashboard');
    } catch (error) {
      console.error('Login failed:', error);
    }
  };

  const handlePhoneSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (step === 1) {
      setStep(2);
    } else {
      // Mock OTP verification
      navigate('/dashboard');
    }
  };

  return (
    <div className="max-w-md mx-auto px-4 py-24">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="cyber-card border-cyber-blue/40"
      >
        <div className="text-center mb-8">
          <Shield className="w-12 h-12 text-cyber-blue mx-auto mb-4" />
          <h1 className="text-2xl font-bold tracking-widest uppercase">ACCESS PROTOCOL</h1>
          <p className="text-xs text-gray-500 mt-2 uppercase tracking-widest">Identity Verification Required</p>
        </div>

        <div className="flex border-b border-cyber-blue/20 mb-8">
          <button
            onClick={() => setMethod('google')}
            className={`flex-1 py-3 text-xs tracking-widest uppercase transition-colors ${method === 'google' ? 'text-cyber-blue border-b-2 border-cyber-blue' : 'text-gray-500'}`}
          >
            GOOGLE AUTH
          </button>
          <button
            onClick={() => setMethod('phone')}
            className={`flex-1 py-3 text-xs tracking-widest uppercase transition-colors ${method === 'phone' ? 'text-cyber-blue border-b-2 border-cyber-blue' : 'text-gray-500'}`}
          >
            WHATSAPP OTP
          </button>
        </div>

        {method === 'google' ? (
          <div className="space-y-6">
            <p className="text-sm text-gray-400 text-center">
              Secure authentication via Google OAuth 2.0. No password storage required.
            </p>
            <motion.button
              whileHover={{ scale: 1.02, backgroundColor: 'rgba(0, 242, 255, 0.15)' }}
              whileTap={{ scale: 0.98 }}
              onClick={handleGoogleLogin}
              className="w-full cyber-button flex items-center justify-center space-x-3 py-3 group transition-all"
            >
              <Mail className="w-5 h-5 group-hover:text-white transition-colors" />
              <span className="group-hover:text-white transition-colors">INITIALIZE GOOGLE AUTH</span>
            </motion.button>
          </div>
        ) : (
          <form onSubmit={handlePhoneSubmit} className="space-y-6">
            {step === 1 ? (
              <div className="space-y-4">
                <label className="block text-[10px] text-cyber-blue uppercase tracking-widest">Phone Number (WhatsApp)</label>
                <div className="relative">
                  <Smartphone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+62 812 XXXX XXXX"
                    className="w-full bg-cyber-black border border-cyber-blue/20 px-10 py-3 text-sm focus:outline-none focus:border-cyber-blue focus:ring-1 focus:ring-cyber-blue/30 focus:shadow-[0_0_15px_rgba(0,242,255,0.15)] transition-all duration-500 ease-out"
                    required
                  />
                </div>
                <motion.button 
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  type="submit" 
                  className="w-full cyber-button flex items-center justify-center space-x-2"
                >
                  <span>SEND OTP</span>
                  <ArrowRight className="w-4 h-4" />
                </motion.button>
              </div>
            ) : (
              <div className="space-y-4">
                <label className="block text-[10px] text-cyber-blue uppercase tracking-widest">Enter Verification Code</label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                  <input
                    type="text"
                    value={otp}
                    onChange={(e) => setOtp(e.target.value)}
                    placeholder="X-X-X-X-X-X"
                    className="w-full bg-cyber-black border border-cyber-blue/20 px-10 py-3 text-sm focus:outline-none focus:border-cyber-blue focus:ring-1 focus:ring-cyber-blue/30 focus:shadow-[0_0_15px_rgba(0,242,255,0.15)] text-center tracking-[0.5em] transition-all duration-500 ease-out"
                    required
                  />
                </div>
                <motion.button 
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  type="submit" 
                  className="w-full cyber-button flex items-center justify-center space-x-2 bg-cyber-green/10 border-cyber-green text-cyber-green hover:bg-cyber-green/20"
                >
                  <span>VERIFY IDENTITY</span>
                </motion.button>
                <button onClick={() => setStep(1)} className="w-full text-[10px] text-gray-500 uppercase tracking-widest hover:text-white">
                  Resend Code
                </button>
              </div>
            )}
          </form>
        )}

        <div className="mt-12 pt-6 border-t border-cyber-blue/10 text-center">
          <div className="flex items-center justify-center space-x-2 text-[10px] text-gray-600 uppercase tracking-widest">
            <Shield className="w-3 h-3" />
            <span>End-to-End Encrypted Session</span>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default Login;
