import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Shield, Activity, Bell, Search, Globe, 
  Cpu, AlertTriangle, CheckCircle, Terminal,
  Lock, Key, Eye, EyeOff
} from 'lucide-react';
import { useUser } from '../hooks/useUser';
import axios from 'axios';
import { ScanResult } from '../types';

const Dashboard: React.FC = () => {
  const { profile, loading } = useUser();
  const [scanUrl, setScanUrl] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);

  const handleScan = async () => {
    if (!scanUrl) return;
    setIsScanning(true);
    try {
      const res = await axios.post('/api/scan', { url: scanUrl });
      setScanResult(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setIsScanning(false);
    }
  };

  const getPasswordStrength = (pass: string) => {
    if (!pass) return { label: 'EMPTY', color: 'text-gray-500', width: '0%' };
    let score = 0;
    if (pass.length > 8) score++;
    if (/[A-Z]/.test(pass)) score++;
    if (/[0-9]/.test(pass)) score++;
    if (/[^A-Za-z0-9]/.test(pass)) score++;

    if (score <= 1) return { label: 'CRITICAL', color: 'text-cyber-red', width: '25%' };
    if (score === 2) return { label: 'WARNING', color: 'text-yellow-500', width: '50%' };
    if (score === 3) return { label: 'SECURE', color: 'text-cyber-blue', width: '75%' };
    return { label: 'FORTIFIED', color: 'text-cyber-green', width: '100%' };
  };

  const strength = getPasswordStrength(password);

  if (loading) return (
    <div className="flex items-center justify-center min-h-[80vh]">
      <div className="text-cyber-blue animate-pulse tracking-[0.5em] uppercase">Initializing Secure Environment...</div>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-widest uppercase">COMMAND CENTER</h1>
          <p className="text-xs text-gray-500 uppercase tracking-widest">Welcome back, {profile?.displayName}</p>
        </div>
        <div className="flex items-center space-x-4">
          <div className={`px-4 py-1 border text-[10px] tracking-widest uppercase rounded-full ${
            profile?.securityStatus === 'secure' ? 'border-cyber-green/30 text-cyber-green bg-cyber-green/5' : 'border-cyber-red/30 text-cyber-red bg-cyber-red/5'
          }`}>
            Status: {profile?.securityStatus}
          </div>
          <button className="p-2 border border-cyber-blue/20 hover:bg-cyber-blue/10 transition-colors">
            <Bell className="w-5 h-5 text-cyber-blue" />
          </button>
        </div>
      </div>

      {/* Grid Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Left Column: Stats & Activity */}
        <div className="lg:col-span-2 space-y-8">
          
          {/* Vulnerability Scanner */}
          <div className="cyber-card">
            <div className="flex items-center space-x-2 mb-6">
              <Search className="w-5 h-5 text-cyber-blue" />
              <h2 className="font-bold tracking-widest uppercase text-sm">Vulnerability Scanner</h2>
            </div>
            <div className="flex gap-2 mb-6">
              <input 
                type="text"
                value={scanUrl}
                onChange={(e) => setScanUrl(e.target.value)}
                placeholder="Enter URL to scan (e.g., https://example.com)"
                className="flex-1 bg-cyber-black border border-cyber-blue/20 px-4 py-2 text-sm focus:outline-none focus:border-cyber-blue"
              />
              <button 
                onClick={handleScan}
                disabled={isScanning}
                className="cyber-button text-xs py-2"
              >
                {isScanning ? 'SCANNING...' : 'INITIALIZE SCAN'}
              </button>
            </div>

            {scanResult && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="space-y-4"
              >
                <div className="flex items-center justify-between p-4 bg-cyber-black/40 border border-cyber-blue/10">
                  <div className="text-xs uppercase tracking-widest text-gray-400">Security Score</div>
                  <div className={`text-2xl font-bold ${scanResult.score > 80 ? 'text-cyber-green' : 'text-cyber-red'}`}>
                    {scanResult.score}/100
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {scanResult.vulnerabilities.map((v, i) => (
                    <div key={i} className="p-3 border border-white/5 bg-white/5 flex items-start space-x-3">
                      {v.status === 'Safe' ? <CheckCircle className="w-4 h-4 text-cyber-green" /> : <AlertTriangle className="w-4 h-4 text-cyber-red" />}
                      <div>
                        <div className="text-[10px] font-bold uppercase tracking-widest">{v.name}</div>
                        <div className="text-[10px] text-gray-500 mt-1">{v.detail}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            )}
          </div>

          {/* Activity Logs */}
          <div className="cyber-card">
            <div className="flex items-center space-x-2 mb-6">
              <Activity className="w-5 h-5 text-cyber-green" />
              <h2 className="font-bold tracking-widest uppercase text-sm">Security Activity Logs</h2>
            </div>
            <div className="space-y-3">
              {[
                { time: '10:42:01', event: 'Login attempt from Jakarta, ID', status: 'SUCCESS' },
                { time: '09:15:33', event: 'Password strength check performed', status: 'INFO' },
                { time: '08:00:12', event: 'Automated system scan completed', status: 'SUCCESS' },
                { time: 'Yesterday', event: 'Unauthorized access attempt blocked', status: 'BLOCKED' },
              ].map((log, i) => (
                <div key={i} className="flex items-center justify-between text-[10px] p-2 border-b border-white/5 font-mono">
                  <div className="flex items-center space-x-4">
                    <span className="text-gray-600">[{log.time}]</span>
                    <span className="text-gray-300 uppercase tracking-widest">{log.event}</span>
                  </div>
                  <span className={log.status === 'BLOCKED' ? 'text-cyber-red' : 'text-cyber-green'}>{log.status}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Tools */}
        <div className="space-y-8">
          
          {/* Password Checker */}
          <div className="cyber-card border-cyber-green/20">
            <div className="flex items-center space-x-2 mb-6">
              <Key className="w-5 h-5 text-cyber-green" />
              <h2 className="font-bold tracking-widest uppercase text-sm">Vault Strength</h2>
            </div>
            <div className="space-y-4">
              <div className="relative">
                <input 
                  type={showPass ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter password to test..."
                  className="w-full bg-cyber-black border border-cyber-green/20 px-4 py-2 text-sm focus:outline-none focus:border-cyber-green"
                />
                <button 
                  onClick={() => setShowPass(!showPass)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white"
                >
                  {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-[10px] uppercase tracking-widest">
                  <span>Strength: <span className={strength.color}>{strength.label}</span></span>
                  <span>{strength.width}</span>
                </div>
                <div className="h-1 bg-white/5 w-full">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: strength.width }}
                    className={`h-full ${strength.color.replace('text-', 'bg-')}`}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Quick Tools */}
          <div className="cyber-card border-cyber-red/20">
            <div className="flex items-center space-x-2 mb-6">
              <Cpu className="w-5 h-5 text-cyber-red" />
              <h2 className="font-bold tracking-widest uppercase text-sm">System Tools</h2>
            </div>
            <div className="grid grid-cols-1 gap-3">
              <button className="w-full p-3 bg-white/5 border border-white/10 text-[10px] uppercase tracking-widest hover:bg-cyber-red/10 hover:border-cyber-red/30 transition-all text-left flex items-center justify-between">
                <span>IP Lookup Tool</span>
                <Globe className="w-4 h-4" />
              </button>
              <button className="w-full p-3 bg-white/5 border border-white/10 text-[10px] uppercase tracking-widest hover:bg-cyber-red/10 hover:border-cyber-red/30 transition-all text-left flex items-center justify-between">
                <span>DNS Analyzer</span>
                <Terminal className="w-4 h-4" />
              </button>
              <button className="w-full p-3 bg-white/5 border border-white/10 text-[10px] uppercase tracking-widest hover:bg-cyber-red/10 hover:border-cyber-red/30 transition-all text-left flex items-center justify-between">
                <span>Port Scanner</span>
                <Lock className="w-4 h-4" />
              </button>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default Dashboard;
