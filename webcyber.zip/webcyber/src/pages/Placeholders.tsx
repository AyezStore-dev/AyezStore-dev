import React from 'react';
import { motion } from 'framer-motion';

const PlaceholderPage: React.FC<{ title: string }> = ({ title }) => (
  <div className="max-w-7xl mx-auto px-4 py-24 text-center">
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="cyber-card"
    >
      <h1 className="text-4xl font-bold tracking-widest uppercase mb-4 text-cyber-blue">{title}</h1>
      <p className="text-gray-400 uppercase tracking-widest text-xs">Accessing encrypted data node...</p>
      <div className="mt-8 h-1 bg-cyber-blue/20 w-full overflow-hidden">
        <motion.div 
          animate={{ x: ['-100%', '100%'] }}
          transition={{ repeat: Infinity, duration: 2, ease: "linear" }}
          className="h-full bg-cyber-blue w-1/3"
        />
      </div>
    </motion.div>
  </div>
);

export const About = () => <PlaceholderPage title="ABOUT CYBERGUARD" />;
export const Services = () => <PlaceholderPage title="SECURITY SERVICES" />;
export const Blog = () => {
  const topics = [
    {
      title: "Dasar Cyber Security",
      desc: "Memahami konsep dasar perlindungan aset digital dan data sensitif.",
      icon: "🛡️",
      details: "Cyber security bukan hanya soal teknologi, tapi juga proses dan orang. Konsep utamanya adalah CIA Triad: Confidentiality (Kerahasiaan), Integrity (Integritas), dan Availability (Ketersediaan). Kerahasiaan memastikan data hanya diakses oleh yang berhak. Integritas menjamin data tidak diubah secara ilegal. Ketersediaan memastikan sistem dapat diakses saat dibutuhkan."
    },
    {
      title: "Anatomi Phishing",
      desc: "Teknik penipuan digital yang paling umum dan cara menghindarinya.",
      icon: "🎣",
      details: "Phishing berkembang menjadi berbagai bentuk: Spear Phishing (target spesifik), Whaling (target eksekutif), dan Vishing (melalui suara/telepon). Ciri khasnya adalah rasa urgensi, permintaan data sensitif, dan link/lampiran mencurigakan. Selalu verifikasi pengirim, periksa URL dengan mengarahkan kursor (hover), dan jangan pernah memberikan kredensial melalui saluran tidak resmi."
    },
    {
      title: "Jenis-Jenis Malware",
      desc: "Mengenal berbagai perangkat lunak berbahaya yang mengancam sistem.",
      icon: "🦠",
      details: "Malware mencakup: 1. Virus (menempel pada file), 2. Worms (menyebar mandiri di jaringan), 3. Trojans (menyamar sebagai aplikasi berguna), 4. Spyware (mencuri data diam-diam), 5. Adware (iklan paksa), dan 6. Rootkits (memberikan akses admin ke penyerang). Pencegahan terbaik adalah menggunakan EDR (Endpoint Detection and Response) dan selalu memperbarui sistem operasi."
    },
    {
      title: "Strategi Anti-Ransomware",
      desc: "Melindungi data dari penyanderaan digital dan pemerasan.",
      icon: "💰",
      details: "Ransomware mengenkripsi data Anda dan meminta tebusan (biasanya Crypto). Strategi pertahanan terbaik adalah aturan Backup 3-2-1: Miliki 3 salinan data, simpan di 2 media berbeda, dan 1 salinan harus offline (off-site). Selain itu, batasi hak akses pengguna (Principle of Least Privilege) agar infeksi tidak menyebar ke seluruh jaringan perusahaan."
    },
    {
      title: "Keamanan Jaringan & VPN",
      desc: "Mengamankan jalur komunikasi data di internet publik.",
      icon: "🌐",
      details: "Jaringan Wi-Fi publik sangat berisiko terhadap serangan Man-in-the-Middle (MitM). Gunakan VPN (Virtual Private Network) untuk mengenkripsi lalu lintas data Anda. Pastikan situs yang dikunjungi menggunakan HTTPS (SSL/TLS). Gunakan Firewall untuk memantau lalu lintas masuk dan keluar, serta matikan layanan/port yang tidak diperlukan pada perangkat Anda."
    },
    {
      title: "Manajemen Identitas (IAM)",
      desc: "Pentingnya autentikasi kuat dan kontrol akses.",
      icon: "🔑",
      details: "Password saja tidak cukup. Gunakan Multi-Factor Authentication (MFA) yang menggabungkan: Sesuatu yang Anda tahu (password), Sesuatu yang Anda miliki (smartphone/token), dan Sesuatu dari diri Anda (biometrik). Hindari menggunakan password yang sama untuk banyak akun. Gunakan Password Manager untuk mengelola kredensial yang kompleks dan unik secara aman."
    },
    {
      title: "Keamanan Web & Aplikasi",
      desc: "Melindungi aplikasi dari eksploitasi kode berbahaya.",
      icon: "💻",
      details: "Penyerang sering menggunakan SQL Injection untuk mencuri database atau Cross-Site Scripting (XSS) untuk menyuntikkan script berbahaya ke browser pengguna. Sebagai pengguna, pastikan browser selalu terupdate. Sebagai pengembang, lakukan validasi input yang ketat dan gunakan framework yang memiliki fitur keamanan bawaan."
    },
    {
      title: "Social Engineering",
      desc: "Manipulasi psikologis untuk mendapatkan informasi rahasia.",
      icon: "🧠",
      details: "Penyerang memanfaatkan sifat manusia seperti rasa percaya, takut, atau ingin membantu. Tekniknya termasuk 'Pretexting' (membuat skenario palsu), 'Baiting' (memberikan umpan seperti USB gratis), dan 'Quid Pro Quo' (menawarkan bantuan teknis palsu). Selalu bersikap skeptis terhadap permintaan informasi mendadak, meskipun terlihat berasal dari rekan kerja atau atasan."
    },
    {
      title: "Respon Insiden (IR)",
      desc: "Langkah yang harus diambil saat terjadi kebocoran data.",
      icon: "🚨",
      details: "Jika Anda merasa diretas: 1. Putuskan koneksi internet segera untuk mengisolasi ancaman. 2. Ubah semua password dari perangkat yang aman. 3. Laporkan ke pihak berwenang atau tim IT. 4. Lakukan audit pada log aktivitas untuk melihat apa yang telah diakses. Jangan langsung menghapus data karena bukti digital diperlukan untuk investigasi."
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-12"
      >
        <h1 className="text-4xl font-bold tracking-widest uppercase mb-4 text-cyber-blue">KNOWLEDGE BASE</h1>
        <p className="text-gray-400 uppercase tracking-widest text-xs">Materi Edukasi Cyber Security & Pertahanan Digital</p>
      </motion.div>

      <div className="space-y-8">
        {topics.map((topic, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="cyber-card border-l-4 border-l-cyber-blue bg-cyber-blue/5"
          >
            <div className="flex flex-col md:flex-row gap-6">
              <div className="text-5xl flex-shrink-0 flex items-center justify-center w-20 h-20 bg-cyber-blue/10 rounded-lg">
                {topic.icon}
              </div>
              <div className="flex-1">
                <h3 className="text-2xl font-bold text-cyber-blue mb-2 uppercase tracking-tight">{topic.title}</h3>
                <p className="text-lg text-white font-medium mb-4">{topic.desc}</p>
                <div className="text-sm text-gray-400 leading-relaxed space-y-2">
                  {topic.details.split('. ').map((sentence, i) => (
                    <p key={i}>{sentence}.</p>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.8 }}
        className="mt-12 p-6 border border-cyber-red/20 bg-cyber-red/5 text-center"
      >
        <p className="text-cyber-red text-xs uppercase tracking-[0.2em] font-bold">
          Peringatan: Keamanan digital dimulai dari kesadaran Anda sendiri.
        </p>
      </motion.div>
    </div>
  );
};

export const Contact = () => {
  const whatsappNumber = "6281234567890"; // Example number
  const message = "Hello CyberGuard, I need assistance with my digital security.";
  const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;

  return (
    <div className="max-w-7xl mx-auto px-4 py-24 text-center">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="cyber-card max-w-2xl mx-auto"
      >
        <h1 className="text-4xl font-bold tracking-widest uppercase mb-4 text-cyber-blue">SECURE CONTACT</h1>
        <p className="text-gray-400 uppercase tracking-widest text-xs mb-8">Establish encrypted communication channel</p>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-6 border border-cyber-blue/20 bg-cyber-blue/5">
            <h3 className="text-cyber-blue font-bold mb-2 uppercase tracking-widest text-sm">Direct Line</h3>
            <p className="text-xs text-gray-500 mb-4">Immediate response via WhatsApp Secure Protocol</p>
            <a 
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="cyber-button inline-block w-full text-center"
            >
              OPEN WHATSAPP
            </a>
          </div>
          <div className="p-6 border border-cyber-green/20 bg-cyber-green/5">
            <h3 className="text-cyber-green font-bold mb-2 uppercase tracking-widest text-sm">Email Node</h3>
            <p className="text-xs text-gray-500 mb-4">PGP Encrypted Email Communication</p>
            <button className="cyber-button border-cyber-green text-cyber-green hover:bg-cyber-green/10 w-full">
              SEND EMAIL
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
