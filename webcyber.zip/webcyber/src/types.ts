export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL: string;
  phoneNumber?: string;
  role: 'user' | 'admin';
  createdAt: string;
  lastLogin: string;
  securityStatus: 'secure' | 'warning' | 'critical';
}

export interface Message {
  id?: string;
  userId: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: string;
}

export interface ScanResult {
  status: 'completed' | 'scanning';
  url: string;
  vulnerabilities: {
    name: string;
    status: 'Safe' | 'Warning' | 'Critical';
    detail: string;
  }[];
  score: number;
}
