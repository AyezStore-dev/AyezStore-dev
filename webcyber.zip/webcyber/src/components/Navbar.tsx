import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Shield, LogOut, User, Menu } from 'lucide-react';
import { auth } from '../firebase';
import { useAuthState } from 'react-firebase-hooks/auth';

const Navbar: React.FC = () => {
  const [user] = useAuthState(auth);
  const navigate = useNavigate();

  const handleLogout = async () => {
    await auth.signOut();
    navigate('/');
  };

  return (
    <nav className="fixed top-0 left-0 w-full z-50 bg-cyber-black/80 backdrop-blur-lg border-bottom border-cyber-blue/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center space-x-2 group">
            <Shield className="w-8 h-8 text-cyber-blue group-hover:rotate-12 transition-transform" />
            <span className="text-xl font-bold tracking-tighter text-white">
              CYBER<span className="text-cyber-blue">GUARD</span>
            </span>
          </Link>

          <div className="hidden md:flex items-center space-x-8">
            <Link to="/services" className="text-sm hover:text-cyber-blue transition-colors">SERVICES</Link>
            <Link to="/about" className="text-sm hover:text-cyber-blue transition-colors">ABOUT</Link>
            <Link to="/blog" className="text-sm hover:text-cyber-blue transition-colors">KNOWLEDGE</Link>
            <Link to="/contact" className="text-sm hover:text-cyber-blue transition-colors">CONTACT</Link>
            
            {user ? (
              <div className="flex items-center space-x-4">
                <Link to="/dashboard" className="flex items-center space-x-2 text-sm hover:text-cyber-blue transition-colors">
                  <User className="w-4 h-4" />
                  <span>DASHBOARD</span>
                </Link>
                <button 
                  onClick={handleLogout}
                  className="flex items-center space-x-2 text-sm text-cyber-red hover:text-red-400 transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                  <span>LOGOUT</span>
                </button>
              </div>
            ) : (
              <Link to="/login" className="cyber-button text-xs py-1 px-4">
                LOGIN
              </Link>
            )}
          </div>

          <div className="md:hidden">
            <Menu className="w-6 h-6 text-cyber-blue" />
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
