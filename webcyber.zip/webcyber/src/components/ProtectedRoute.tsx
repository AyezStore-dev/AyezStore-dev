import React from 'react';
import { Navigate } from 'react-router-dom';
import { useUser } from '../hooks/useUser';

const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, loading } = useUser();

  if (loading) return (
    <div className="flex items-center justify-center min-h-screen bg-cyber-black">
      <div className="text-cyber-blue animate-pulse tracking-[0.5em] uppercase">Authenticating Session...</div>
    </div>
  );

  if (!user) {
    return <Navigate to="/login" />;
  }

  return <>{children}</>;
};

export default ProtectedRoute;
