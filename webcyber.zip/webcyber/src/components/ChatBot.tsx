import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, Send, X, Bot, User, Check, CheckCheck } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import axios from 'axios';

interface Message {
  text: string;
  sender: 'user' | 'bot';
  timestamp: string;
  status?: 'sent' | 'delivered' | 'read';
}

const ChatBot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    { 
      text: "Hello! I am CyberGuard AI. How can I help you with your digital security today?", 
      sender: 'bot',
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: 'read'
    }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg = input;
    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    setInput('');
    setMessages(prev => [...prev, { text: userMsg, sender: 'user', timestamp, status: 'sent' }]);
    setIsLoading(true);

    try {
      const response = await axios.post('/api/chat', { 
        message: userMsg,
        history: messages.map(m => ({
          role: m.sender === 'user' ? 'user' : 'model',
          parts: [{ text: m.text }]
        }))
      });
      
      const botTimestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      
      // Update user message to 'read' when bot responds
      setMessages(prev => {
        const updated = [...prev];
        if (updated.length > 0) {
          updated[updated.length - 1].status = 'read';
        }
        return [...updated, { text: response.data.text, sender: 'bot', timestamp: botTimestamp, status: 'read' }];
      });
    } catch (error) {
      const errorTimestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      setMessages(prev => [...prev, { text: "Sorry, I encountered an error. Please try again.", sender: 'bot', timestamp: errorTimestamp, status: 'read' }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 20 }}
            className="cyber-card w-80 sm:w-96 h-[500px] flex flex-col mb-4 border-cyber-blue"
          >
            <div className="flex items-center justify-between mb-4 border-b border-cyber-blue/20 pb-2">
              <div className="flex items-center space-x-2">
                <Bot className="w-5 h-5 text-cyber-blue" />
                <span className="font-bold text-sm tracking-widest">CYBERGUARD AI</span>
              </div>
              <button onClick={() => setIsOpen(false)} className="text-cyber-blue hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div 
              ref={scrollRef}
              className="flex-1 overflow-y-auto space-y-4 mb-4 pr-2 custom-scrollbar"
            >
              {messages.map((msg, i) => (
                <div key={i} className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}>
                  <div className={`max-w-[85%] p-3 rounded-sm text-xs relative ${
                    msg.sender === 'user' 
                      ? 'bg-cyber-blue/20 border border-cyber-blue/40 text-white' 
                      : 'bg-cyber-black/60 border border-cyber-green/40 text-cyber-green'
                  }`}>
                    <div className="flex items-center space-x-2 mb-1 opacity-50">
                      {msg.sender === 'user' ? <User className="w-3 h-3" /> : <Bot className="w-3 h-3" />}
                      <span className="uppercase text-[10px]">{msg.sender}</span>
                    </div>
                    <div className="mb-1">{msg.text}</div>
                    <div className="flex items-center justify-end space-x-1 mt-1 opacity-40 text-[9px]">
                      <span>{msg.timestamp}</span>
                      {msg.sender === 'user' && (
                        <span>
                          {msg.status === 'read' ? (
                            <CheckCheck className="w-3 h-3 text-cyber-blue" />
                          ) : (
                            <Check className="w-3 h-3" />
                          )}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-cyber-black/60 border border-cyber-green/40 p-3 rounded-sm text-xs text-cyber-green animate-pulse">
                    Analyzing security protocols...
                  </div>
                </div>
              )}
            </div>

            <div className="flex space-x-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                placeholder="Type your security query..."
                className="flex-1 bg-cyber-black border border-cyber-blue/40 px-3 py-2 text-xs focus:outline-none focus:border-cyber-blue"
              />
              <button 
                onClick={handleSend}
                className="bg-cyber-blue text-cyber-black p-2 hover:bg-white transition-colors"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-14 h-14 bg-cyber-blue text-cyber-black rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(0,242,255,0.5)] hover:scale-110 transition-transform"
      >
        <MessageSquare className="w-6 h-6" />
      </button>
    </div>
  );
};

export default ChatBot;
