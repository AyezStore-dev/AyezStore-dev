import React from 'react';
import Navbar from './Navbar';
import MatrixBackground from './MatrixBackground';
import ChatBot from './ChatBot';

const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <div className="min-h-screen relative">
      <MatrixBackground />
      <Navbar />
      <main className="pt-16 min-h-screen">
        {children}
      </main>
      <ChatBot />
      <div className="scan-line" />
    </div>
  );
};

export default Layout;
