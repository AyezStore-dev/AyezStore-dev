import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import cookieParser from 'cookie-parser';
import rateLimit from 'express-rate-limit';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());
  app.use(cookieParser());

  // Rate limiting
  const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // limit each IP to 100 requests per windowMs
    message: { error: 'Too many requests, please try again later.' }
  });
  app.use('/api/', limiter);

  // AI Chatbot Endpoint
  app.post('/api/chat', async (req, res) => {
    try {
      const { message, history } = req.body;
      
      const response = await ai.models.generateContent({
        model: 'gemini-1.5-flash',
        contents: [
          { role: 'user', parts: [{ text: 'You are CyberGuard AI, a professional cyber security expert. Provide helpful, accurate, and concise security tips and answers. Use a professional yet futuristic tone.' }] },
          ...(history || []).map((h: any) => ({
            role: h.role === 'model' ? 'model' : 'user',
            parts: h.parts
          })),
          { role: 'user', parts: [{ text: message }] }
        ]
      });

      const responseText = response.text;
      
      res.json({ text: responseText });
    } catch (error) {
      console.error('AI Chat Error:', error);
      res.status(500).json({ error: 'Failed to get AI response' });
    }
  });

  // Basic Vulnerability Scan Mock API
  app.post('/api/scan', async (req, res) => {
    const { url } = req.body;
    // Mock scan results
    setTimeout(() => {
      res.json({
        status: 'completed',
        url,
        vulnerabilities: [
          { name: 'XSS Protection', status: 'Safe', detail: 'Headers properly configured' },
          { name: 'SQL Injection', status: 'Safe', detail: 'No vulnerable entry points found' },
          { name: 'SSL/TLS', status: 'Warning', detail: 'Certificate expires in 30 days' },
          { name: 'Open Ports', status: 'Critical', detail: 'Port 21 (FTP) is open and insecure' }
        ],
        score: 75
      });
    }, 2000);
  });

  // IP Lookup Mock API
  app.get('/api/ip-lookup/:ip', async (req, res) => {
    const { ip } = req.params;
    res.json({
      ip,
      location: 'Jakarta, Indonesia',
      isp: 'CyberNet Solutions',
      type: 'Business',
      riskScore: 12
    });
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
